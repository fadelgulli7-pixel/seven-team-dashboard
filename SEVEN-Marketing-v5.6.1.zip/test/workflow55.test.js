'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path');
const {createApp}=require('../server'),C=require('../lib/channels'),Campaigns=require('../lib/campaigns');
test('optional telephone, project contact exemption and scheduled deliverables are enforced',()=>{
 assert.deepEqual(C.contact({fullName:'Member Full Name'}),{fullName:'Member Full Name',phone:''});
 assert.throws(()=>C.contact({fullName:'Member Full Name',phone:'abc'}));
 assert.deepEqual(C.contact({role:'Owner',name:'SEVEN Network'}),{});
 const owner={id:'owner',role:'Owner'},d={activities:[]},b={title:'Invite explainer',objective:'Explain invitations accurately',brief:'Create an original post showing the invite screen and correct steps.',startsAt:new Date(Date.now()+3600000).toISOString(),deadline:new Date(Date.now()+86400000).toISOString(),maxPerMember:3,gapHours:24,topic:'Invites',deliverable:'Post'};
 const c=Campaigns.create(d,b,owner);assert.throws(()=>Campaigns.source(d,{id:'member'},{campaignId:c.id,platform:'Telegram',rewardType:'telegram_post'}));
 c.startsAt=new Date(Date.now()-1000).toISOString();assert.equal(Campaigns.source(d,{id:'member'},{campaignId:c.id,platform:'Telegram',rewardType:'telegram_post'}).id,c.id);
 assert.throws(()=>Campaigns.source(d,{id:'member'},{campaignId:c.id,platform:'Telegram',rewardType:'tutorial'}));Campaigns.validate(d);
});
test('session survives a real server restart; hashed tokens only; logout and password revocation persist',async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'seven-session-'));let app;const env={SETUP_TOKEN:'test-setup-token-123456789000'};
 async function start(){app=await createApp({dataDir:dir,env});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));return 'http://127.0.0.1:'+app.server.address().port;}
 let url=await start();t.after(async()=>{await app.close();await fs.rm(dir,{recursive:true,force:true});});let cookie='',csrf='';
 async function call(route,b){const r=await fetch(url+route,{method:b?'POST':'GET',headers:{'Content-Type':'application/json',Cookie:cookie,'X-CSRF-Token':csrf},...(b?{body:JSON.stringify(b)}:{})});if(r.headers.get('set-cookie'))cookie=r.headers.get('set-cookie').split(';')[0];const body=await r.json();if(body.csrf)csrf=body.csrf;return {status:r.status,body};}
 assert.equal((await call('/api/setup',{name:'SEVEN Network',username:'owner',password:'Owner-test-12345!',walletAddress:'mvines9iiHiQTysrwkJjGf2gb9Ex9jXJX8ns3qwf2kN',setupToken:env.SETUP_TOKEN})).status,201);
 const raw=cookie.split('=')[1];assert.ok(!(await fs.readFile(path.join(dir,'sessions.json'),'utf8')).includes(raw));
 await app.close();url=await start();assert.equal((await call('/api/me')).status,200);
 const profile=await call('/api/profile',{name:'SEVEN Network',fullName:'',phone:'',photo:'',walletAddress:'mvines9iiHiQTysrwkJjGf2gb9Ex9jXJX8ns3qwf2kN'});assert.equal(profile.status,200);assert.equal(profile.body.member.fullName,undefined);assert.equal(profile.body.member.phone,undefined);assert.equal(profile.body.member.profileComplete,true);
 assert.equal((await call('/api/password',{currentPassword:'Owner-test-12345!',newPassword:'Updated-test-12345!'})).status,200);const fresh=cookie;cookie='seven_session='+raw;assert.equal((await call('/api/me')).status,401);cookie=fresh;
 await call('/api/logout',{});await app.close();url=await start();cookie=fresh;assert.equal((await call('/api/me')).status,401);
});
