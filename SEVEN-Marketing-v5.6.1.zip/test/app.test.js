'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const vm = require('node:vm');
const {createApp} = require('../server');
const {FileStore, validate} = require('../lib/store');
const {hashPassword, verifyPassword, equalSecret, Limiter} = require('../lib/security');
const password = 'Owner-test-only-482!';
const setupToken = 'test-only-setup-code-1234567890';
async function directory(t) { const dir = await fs.mkdtemp(path.join(os.tmpdir(),'seven-test-')); t.after(()=>fs.rm(dir,{recursive:true,force:true})); return dir; }
async function fixture(t,env={}) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(),'seven-test-'));
  const app = await createApp({dataDir:dir,env:{SETUP_TOKEN:setupToken,...env},treasury:async()=>({snapshot:null,error:'Test source offline'})});
  await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));
  t.after(async()=>{await app.close();await fs.rm(dir,{recursive:true,force:true});});
  const url='http://127.0.0.1:'+app.server.address().port;
  function client() {
    let cookie='',csrf='',memberId='';
    return async (route,body,extra={})=>{
      // Legacy behavior cases use pre-reviewed promotion sources. Dedicated
      // onboarding tests below exercise the real pending/review API.
      if(body && (route==='/api/activities'||/^\/api\/activities\/.*\/edit$/.test(route)) && memberId){
        const key=crypto.createHash('sha256').update(memberId+(body.platform||'Other')).digest('hex');const sourceId=[key.slice(0,8),key.slice(8,12),key.slice(12,16),key.slice(16,20),key.slice(20,32)].join('-');
        await app.store.transaction(d=>{const m=d.members.find(m=>m.id===memberId);m.fullName='Test Full Name';m.phone='+9647501234567';m.channels??=[];const hosts={'X (Twitter)':'x.com/test',Telegram:'t.me/test',YouTube:'youtube.com/@test',TikTok:'tiktok.com/@test',Instagram:'instagram.com/test',Discord:'discord.gg/test',Facebook:'facebook.com/test'};if(!m.channels.some(c=>c.id===sourceId))m.channels.push({id:sourceId,platform:body.platform||'Other',url:'https://'+(hosts[body.platform]||'example.com/test'),status:'approved',version:1,activeConfirmed:true,ownershipConfirmed:true,reviewerId:d.members[0].id,note:'Fixture pre-reviewed source'});});
        const campaignId='11111111-1111-4111-8111-111111111111';await app.store.transaction(d=>{d.campaigns??=[{id:campaignId,title:'Fixture campaign',objective:'Reviewed fixture marketing',brief:'Fixture content acceptance criteria for original work',deadline:new Date(Date.now()+86400000).toISOString(),maxPerMember:30,gapHours:1,active:true}];for(const a of d.activities)if(a.memberId===memberId&&a.requestKey!==body.requestKey)a.createdAt=new Date(Date.now()-7200000).toISOString();});body={...body,sourceId,campaignId};
      }
      if(body&&/^\/api\/activities\/.*\/review$/.test(route))body={score_accuracy:18,score_originality:18,score_usefulness:18,score_production:18,score_compliance:18,...body};
      const response=await fetch(url+route,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',Cookie:cookie,'X-CSRF-Token':csrf,...extra},...(body===undefined?{}:{body:JSON.stringify(['/api/setup','/api/members','/api/profile'].includes(route)?{walletAddress:'mvines9iiHiQTysrwkJjGf2gb9Ex9jXJX8ns3qwf2kN',fullName:'Test Full Name',phone:'+9647501234567',...body}:body)})});
      if(response.headers.get('set-cookie'))cookie=response.headers.get('set-cookie').split(';')[0];
      const value=await response.json(); if(value.member)memberId=value.member.id; if(value.csrf)csrf=value.csrf;
      return {status:response.status,body:value};
    };
  }
  const owner=client();
  assert.equal((await owner('/api/setup',{name:'Test Owner',username:'owner',password,setupToken})).status,201);
  return {app,dir,url,client,owner};
}
test('password hashes are salted, bounded and verified; rate limits expire', async()=>{
  const a=await hashPassword(password),b=await hashPassword(password);
  assert.notEqual(a.hash,b.hash); assert(await verifyPassword(password,a)); assert.equal(await verifyPassword('incorrect',a),false);
  assert.equal(await verifyPassword({},a),false); assert.equal(await verifyPassword('x'.repeat(201),a),false);
  assert(equalSecret('abc','abc')); assert.equal(equalSecret(undefined,'abc'),false);
  const l=new Limiter();assert(l.take('a',1,1000));assert.equal(l.take('a',1,1000),false);l.items.get('a').until=0;assert(l.take('a',1,1000));l.clear('a');assert(l.take('a',1,1000));
});
test('setup is protected and single-use; anonymous, CSRF and origin requests blocked', async t=>{
  const f=await fixture(t),anonymous=f.client();
  assert.equal((await anonymous('/api/data')).status,401);
  assert.equal((await anonymous('/api/setup',{setupToken})).status,409);
  assert.equal((await f.owner('/api/members',{}, {'X-CSRF-Token':''})).status,403);
  assert.equal((await f.owner('/api/members',{}, {Origin:'https://evil.example'})).status,403);
  assert.equal((await f.owner('/health')).body.ok,true);
  const data=(await f.owner('/api/data')).body;assert.equal(data.members.length,1);assert.equal(data.members[0].hash,undefined);assert.equal(data.members[0].salt,undefined);
});
test('missing or wrong setup token cannot create owner',async t=>{
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'seven-test-')),app=await createApp({dataDir:dir,env:{}});t.after(async()=>{await app.close();await fs.rm(dir,{recursive:true,force:true});});
  await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
  const response=await fetch('http://127.0.0.1:'+app.server.address().port+'/api/setup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({setupToken:'wrong'})});
  assert.equal(response.status,503);assert.equal(app.store.data.members.length,0);
});
test('member workflow, concurrent duplicates, rejection, correction, approval, stale version and suspension',async t=>{
  const f=await fixture(t);
  const created=await f.owner('/api/members',{name:'Test Member',username:'member',password});assert.equal(created.status,201);
  const member=f.client();assert.equal((await member('/api/login',{username:'member',password})).status,200);
  assert.equal((await member('/api/data')).status,403);
  assert.equal((await member('/api/password',{currentPassword:password,newPassword:'Member-changed-482!'})).status,200);
  assert.equal((await member('/api/members',{name:'Not Allowed',username:'other',password})).status,403);
  assert.equal((await member('/api/backup',{password:'Member-changed-482!'})).status,403);
  const work={title:'Community post',category:'Community',platform:'Telegram',description:'Test work',link:'https://example.com/proof',requestKey:crypto.randomUUID()};
  const submissions=await Promise.all([member('/api/activities',work),member('/api/activities',work)]);
  assert.deepEqual(submissions.map(x=>x.status).sort(),[200,201]);assert.equal(f.app.store.data.activities.length,1);
  const id=submissions[0].body.activity.id;
  assert.equal((await member('/api/activities',{...work,requestKey:crypto.randomUUID()})).status,409);
  assert.equal((await member(`/api/activities/${id}/review`,{version:1,status:'approved'})).status,403);
  assert.equal((await f.owner(`/api/activities/${id}/review`,{version:1,status:'rejected',note:'Fix proof'})).status,200);
  assert.equal((await member(`/api/activities/${id}/edit`,{...work,version:2,description:'Corrected'})).status,200);
  assert.equal((await f.owner(`/api/activities/${id}/review`,{version:1,status:'approved'})).status,409);
  assert.equal((await f.owner(`/api/activities/${id}/review`,{version:3,status:'approved'})).status,200);
  assert.equal((await member(`/api/activities/${id}/edit`,{...work,version:4})).status,409);
  assert.equal(f.app.store.data.activities[0].history.length,3);
  const backup=await f.owner('/api/backup',{password});assert.equal(backup.status,200);validate(backup.body);
  assert.equal((await f.owner('/api/members/'+created.body.member.id,{action:'active',active:false})).status,200);
  assert.equal((await member('/api/data')).status,401);assert.equal(f.app.store.data.activities[0].status,'approved');
});
test('owner cannot self-approve and password reset revokes sessions',async t=>{
  const f=await fixture(t);
  const a=await f.owner('/api/activities',{title:'Owner work',category:'Other',requestKey:crypto.randomUUID()});
  assert.equal((await f.owner('/api/activities/'+a.body.activity.id+'/review',{version:1,status:'approved'})).status,403);
  const m=await f.owner('/api/members',{name:'Manager Test',username:'manager',password,role:'Manager'});
  const manager=f.client();await manager('/api/login',{username:'manager',password});await manager('/api/password',{currentPassword:password,newPassword:'Manager-changed-482!'});
  assert.equal((await manager('/api/activities/'+a.body.activity.id+'/review',{version:1,status:'approved'})).status,200);
  assert.equal((await manager('/api/audit')).status,403);
  await f.owner('/api/members/'+m.body.member.id,{action:'reset-password',password:'Reset-starter-123!'});
  assert.equal((await manager('/api/data')).status,401);
  assert.equal((await manager('/api/login',{username:'manager',password:'Reset-starter-123!'})).body.member.mustChangePassword,true);
});
test('serialized writes survive reopen; lock blocks second writer; failed write rolls back',async t=>{
  const dir=await directory(t),store=await new FileStore(dir).open();
  await assert.rejects(new FileStore(dir).open(),/locked/);
  await Promise.all(Array.from({length:10},(_,i)=>store.transaction(d=>{d.audit.push({action:'test'+i,createdAt:new Date().toISOString()});})));
  assert.equal(store.data.revision,10);
  const previous=await fs.readFile(store.file,'utf8'),write=store.writeAtomic.bind(store);
  store.writeAtomic=async()=>{throw Error('Simulated disk failure');};
  await assert.rejects(store.transaction(d=>d.audit.push({action:'lost',createdAt:new Date().toISOString()})),/disk failure/);
  assert.equal(store.data.audit.length,10);assert.equal(await fs.readFile(store.file,'utf8'),previous);
  store.writeAtomic=write;await store.close();
  const reopened=await new FileStore(dir).open();assert.equal(reopened.data.audit.length,10);await reopened.close();
  assert.equal((await fs.readdir(path.join(dir,'backups'))).length,1);
});
test('corrupt, unknown-schema and missing initialized data fail closed without overwrite',async t=>{
  const dir=await directory(t),s=await new FileStore(dir).open();await s.close();
  for(const raw of ['not json',JSON.stringify({members:[],activities:[]})]) {
    await fs.writeFile(s.file,raw);await assert.rejects(new FileStore(dir).open());assert.equal(await fs.readFile(s.file,'utf8'),raw);
  }
  await fs.unlink(s.file);await assert.rejects(new FileStore(dir).open(),/missing/);
});
test('HTML scripts parse and CSP matches actual inline bytes',async t=>{
  const f=await fixture(t),res=await fetch(f.url),html=await res.text(),csp=res.headers.get('content-security-policy');
  for(const match of html.matchAll(/<script>([\s\S]*?)<\/script>/g)){new vm.Script(match[1]);assert(csp.includes(crypto.createHash('sha256').update(match[1]).digest('base64')));}
  assert.equal((await fetch(f.url+'/lib/store.js')).status,404);
  assert.equal((await fetch(f.url+'/data/team-data.json')).status,404);
});
test('production fails closed without explicit data path',async()=>{
  await assert.rejects(createApp({env:{NODE_ENV:'production'}}),/DATA_DIR/);
});
test('maintenance backup verification and owner recovery preserve records and survive restart',async t=>{
  const {execFile}=require('node:child_process'),{promisify}=require('node:util');
  const run=promisify(execFile),dir=await directory(t),store=await new FileStore(dir).open();
  const id=crypto.randomUUID();
  await store.transaction(async d=>d.members.push({id,name:'Recovery Owner',username:'owner',role:'Owner',active:true,mustChangePassword:false,authVersion:0,createdAt:new Date().toISOString(),...await hashPassword(password)}));
  await store.close();
  const tool=path.join(__dirname,'../tools.js');
  const result=await run(process.execPath,[tool,'verify-backup',path.join(dir,'team-data.json')]);assert.match(result.stdout,/Valid backup: 1 members/);
  await run(process.execPath,[tool,'reset-owner'],{env:{...process.env,DATA_DIR:dir,OWNER_NEW_PASSWORD:'Recovery-password-123!'}});
  const restored=await new FileStore(dir).open();
  const owner=restored.data.members[0];assert.equal(owner.id,id);assert.equal(owner.authVersion,1);assert.equal(owner.mustChangePassword,true);
  assert(await verifyPassword('Recovery-password-123!',owner));assert.equal(await verifyPassword(password,owner),false);
  assert.equal(restored.data.audit.at(-1).action,'owner_password_recovered');await restored.close();
});

test('profile updates are authenticated, private to the member, persisted and validated',async t=>{
  const f=await fixture(t),anonymous=f.client();
  assert.equal((await anonymous('/api/profile',{name:'Changed',photo:''})).status,401);
  assert.equal((await f.owner('/api/profile',{name:'Changed',photo:'data:image/svg+xml;base64,AAAA'})).status,400);
  assert.equal((await f.owner('/api/profile',{name:'A',photo:''})).status,400);
  const m=(await f.owner('/api/members',{name:'Other Person',username:'person',password})).body.member;
  const photo='data:image/jpeg;base64,'+(await fs.readFile(path.join(__dirname,'fixtures/avatar.jpg'))).toString('base64');
  const updated=await f.owner('/api/profile',{name:'New Owner Name',photo,id:m.id});
  assert.equal(updated.status,200);assert.equal(updated.body.member.name,'New Owner Name');
  const result=(await f.owner('/api/data')).body;
  assert.equal(result.members.find(x=>x.id===m.id).name,'Other Person');
  assert.equal(result.member.initials,'NO');
  const disk=JSON.parse(await fs.readFile(path.join(f.dir,'team-data.json'),'utf8'));
  assert.equal(disk.members[0].name,'New Owner Name');assert.equal(disk.members[0].photo,photo);assert.equal(result.member.photo,photo);
  for(const asset of ['seven-logo.png','contributions.js']){const response=await fetch(f.url+'/assets/'+asset);assert.equal(response.status,200);assert((await response.arrayBuffer()).byteLength>100);}
});
test('rankings use approved work only, include everyone, share tied ranks and handle zero work',()=>{
  const {summarize}=require('../assets/contributions');
  const members=[{id:'a',name:'Alpha',active:true},{id:'b',name:'Beta',active:false},{id:'c',name:'Charlie',active:true}];
  const rows=summarize(members,[{memberId:'a',status:'approved'},{memberId:'b',status:'approved'},{memberId:'c',status:'pending'},{memberId:'c',status:'rejected'}]);
  assert.deepEqual(rows.map(m=>[m.id,m.count,m.percent,m.rank]),[['a',1,50,1],['b',1,50,1],['c',0,0,null]]);
  assert.equal(rows.reduce((sum,m)=>sum+m.percent,0),100);
  assert(summarize(members,[]).every(m=>m.percent===0&&m.rank===null));
});

test('frontend summaries render real member names, all rows, percentages and safe text',async()=>{
  const html=await fs.readFile(path.join(__dirname,'../index.html'),'utf8');
  const code=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x=>x[1]).join('\n').replace('bindLanguagePickers();applyLanguage();start();','');
  const elements=new Map();const get=s=>{if(!elements.has(s))elements.set(s,{innerHTML:'',value:({'#chartRange':'week','#reportRange':'all','#statusFilter':'all','#feedLimit':'50'})[s]||'',classList:{toggle(){}}});return elements.get(s)};
  const context=vm.createContext({document:{querySelector:get,querySelectorAll(){return []},addEventListener(){}},localStorage:{getItem(){return 'en'}},Intl,Date,SevenContributions:require('../assets/contributions')});
  vm.runInContext(code,context);
  vm.runInContext(`applyLanguage=()=>{};data={members:[{id:'a',name:'Alice <script>',handle:'@alice',initials:'AL',role:'Owner',active:true},{id:'b',name:'Bob',handle:'@bob',initials:'BO',role:'Member',active:true}],activities:[{id:'work',memberId:'a',title:'Campaign',category:'Marketing',platform:'Telegram',status:'approved',description:'',createdAt:new Date().toISOString()}]};currentUser=data.members[0];render();`,context);
  assert.match(get('#personalSummary').innerHTML,/Alice &lt;script&gt;/);
  assert.match(get('#personalSummary').innerHTML,/\$0.00/);
  assert.match(get('#memberList').innerHTML,/Bob/);
  assert.match(get('#rankList').innerHTML,/\$0.00/);
  assert.equal((get('#homeLeaders').innerHTML.match(/class="podium-card/g)||[]).length,0);
});


test('single-use recovery is password-gated, hash-only, persisted, rotated and revokes all sessions',async t=>{
 const f=await fixture(t),anonymous=f.client(),second=f.client();
 assert.equal((await anonymous('/api/recovery/code',{password})).status,401);
 assert.equal((await f.owner('/api/recovery/code',{password:'wrong-password-000'})).status,401);
 await second('/api/login',{username:'owner',password});
 const old=await f.owner('/api/recovery/code',{password});assert.equal(old.status,201);
 assert.equal((await f.owner('/api/recovery/code',{password}, {'X-CSRF-Token':''})).status,403);
 const issued=await f.owner('/api/recovery/code',{password});assert.equal(issued.status,201);assert.notEqual(old.body.code,issued.body.code);
 const disk=JSON.parse(await fs.readFile(path.join(f.dir,'team-data.json'),'utf8'));
 assert.equal(typeof disk.members[0].recovery.hash,'string');assert(!JSON.stringify(disk).includes(issued.body.code));
 assert(!JSON.stringify((await f.owner('/api/data')).body).includes(disk.members[0].recovery.hash));
 assert.equal((await f.owner('/api/me')).body.member.recoveryReady,true);
 const newPassword='new-recovered-password-7766';
 assert.equal((await anonymous('/api/recovery/reset',{username:'owner',code:old.body.code,newPassword})).status,400);
 const wrong=await anonymous('/api/recovery/reset',{username:'owner',code:'invalid',newPassword});
 const unknown=await anonymous('/api/recovery/reset',{username:'unknown',code:issued.body.code,newPassword});
 assert.equal(wrong.status,unknown.status);assert.equal(wrong.body.error,unknown.body.error);
 assert.equal((await anonymous('/api/recovery/reset',{username:'owner',code:issued.body.code.toLowerCase(),newPassword})).status,200);
 assert.equal((await f.owner('/api/data')).status,401);assert.equal((await second('/api/data')).status,401);
 assert.equal((await anonymous('/api/recovery/reset',{username:'owner',code:issued.body.code,newPassword:'reused-password-0000'})).status,400);
 assert.equal((await anonymous('/api/login',{username:'owner',password})).status,401);
 assert.equal((await anonymous('/api/login',{username:'owner',password:newPassword})).status,200);
 assert.equal((await anonymous('/api/me')).body.member.recoveryReady,false);
 assert(f.app.store.data.audit.some(e=>e.action==='password_recovered'));
 assert.equal(f.app.store.data.members[0].recovery,undefined);
});

test('recovery cannot bypass suspension, expiry or a later owner password reset',async t=>{
 const f=await fixture(t),u=f.client();
 const m=(await f.owner('/api/members',{name:'Recovery User',username:'recover',password})).body.member;
 await u('/api/login',{username:'recover',password});const newPassword='changed-member-password-999';
 await u('/api/password',{currentPassword:password,newPassword});
 const code=(await u('/api/recovery/code',{password:newPassword})).body.code;
 await f.owner('/api/members/'+m.id,{action:'active',active:false});
 const anon=f.client();assert.equal((await anon('/api/recovery/reset',{username:'recover',code,newPassword:'new-long-password-888'})).status,400);
 await f.owner('/api/members/'+m.id,{action:'active',active:true});
 await f.app.store.transaction(d=>{d.members.find(x=>x.id===m.id).recovery.expiresAt='2001-01-01T00:00:00Z'});
 assert.equal((await anon('/api/recovery/reset',{username:'recover',code,newPassword:'new-long-password-888'})).status,400);
 await u('/api/login',{username:'recover',password:newPassword});
 const current=(await u('/api/recovery/code',{password:newPassword})).body.code;
 await f.owner('/api/members/'+m.id,{action:'reset-password',password:'owner-reset-password-4444'});
 assert.equal((await anon('/api/recovery/reset',{username:'recover',code:current,newPassword:'new-long-password-888'})).status,400);
 assert.equal((await anon('/api/login',{username:'recover',password:'owner-reset-password-4444'})).status,200);
});

test('workspace money and contributions share one revision and never leak recovery credentials',async t=>{
 const f=await fixture(t);const response=await f.owner('/api/workspace');assert.equal(response.status,200);
 assert.equal(response.body.members.length,1);assert.equal(response.body.member.recovery,undefined);
 assert.equal(response.body.rewards.currency,'USD');assert.equal(response.body.finance,undefined);assert.equal(response.body.rewards.earnedCents,0);
});

test('recovery codes are consumed atomically under concurrent requests',async t=>{
 const f=await fixture(t),a=f.client(),b=f.client();const code=(await f.owner('/api/recovery/code',{password})).body.code;
 const body={username:'owner',code,newPassword:'concurrent-reset-password-999'};
 const results=await Promise.all([a('/api/recovery/reset',body),b('/api/recovery/reset',body)]);
 assert.deepEqual(results.map(r=>r.status).sort(),[200,400]);
 assert.equal(f.app.store.data.audit.filter(e=>e.action==='password_recovered').length,1);
});

test('recovery entry screens and fixed task reward amounts render without a wallet or revenue source',async()=>{
 const html=await fs.readFile(path.join(__dirname,'../index.html'),'utf8');
 const code=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x=>x[1]).join('\n').replace('bindLanguagePickers();applyLanguage();start();','');
 const elements=new Map();const get=s=>{if(!elements.has(s))elements.set(s,{innerHTML:'',value:({'#chartRange':'week','#reportRange':'all','#statusFilter':'all','#feedLimit':'50'})[s]||'',classList:{toggle(){}},addEventListener(){}});return elements.get(s)};
 const context=vm.createContext({document:{querySelector:get,querySelectorAll(){return []},addEventListener(){}},localStorage:{getItem(){return 'en'}},Intl,Date,SevenContributions:require('../assets/contributions')});vm.runInContext(code,context);vm.runInContext('applyLanguage=()=>{};renderAuth(false);',context);
 assert.match(get('#loginView').innerHTML,/Forgot password\?/);vm.runInContext('renderRecovery();',context);assert.match(get('#loginView').innerHTML,/name="code"/);
 const d={members:[{id:'a',name:'Worker Alpha',role:'Owner',handle:'@alpha',active:true},{id:'b',name:'Worker Beta',role:'Member',handle:'@beta',active:true}],activities:[{id:'x',memberId:'a',status:'approved',category:'Marketing',title:'Publish campaign',description:'',createdAt:new Date().toISOString()}],rewards:{policy:require('../lib/rewards').defaults(),grants:[{id:'grant',memberId:'a',activityId:'x',type:'social_post',amountCents:100,createdAt:new Date().toISOString()}],payments:[]}};
 vm.runInContext('data='+JSON.stringify(d)+';currentUser={...data.members[0],recoveryReady:true};rewards='+JSON.stringify(require('../lib/rewards').summary(d))+';render();',context);
 for(const id of ['#personalSummary','#memberList','#homeLeaders','#rankList'])assert.match(get(id).innerHTML,/\$1.00/);
 for(const v of elements.values()){assert(!v.innerHTML.includes('UQDz'));assert(!v.innerHTML.includes('seven-transparency'));assert(!v.innerHTML.includes('20%'));}
});

test('fixed reward workflow is atomic, private, budgeted and independent of the retired treasury',async t=>{
 const f=await fixture(t),worker=f.client();const m=(await f.owner('/api/members',{name:'Original Creator',username:'creator',password})).body.member;
 await worker('/api/login',{username:'creator',password});await worker('/api/password',{currentPassword:password,newPassword:'creator-password-changed-993'});
 const input={title:'Original Facebook post',category:'Marketing',platform:'Facebook',link:'https://facebook.com/creator/posts/1',rewardType:'social_post',requestKey:crypto.randomUUID()};
 const submitted=await worker('/api/activities',input);assert.equal(submitted.status,201);assert.equal(submitted.body.activity.rewardQuote.amountCents,250);const a=submitted.body.activity;
 const approve={status:'approved',version:1,rewardType:'social_post',originalConfirmed:true,evidenceVerified:true,qualityConfirmed:true};
 assert.equal((await worker(`/api/activities/${a.id}/review`,approve)).status,403);
 assert.equal((await f.owner(`/api/activities/${a.id}/review`,{...approve,qualityConfirmed:false})).status,400);assert.equal(f.app.store.data.activities.find(x=>x.id===a.id).status,'pending');
 const reviews=await Promise.all([f.owner(`/api/activities/${a.id}/review`,approve),f.owner(`/api/activities/${a.id}/review`,approve)]);assert.deepEqual(reviews.map(r=>r.status).sort(),[200,409]);
 let s=(await worker('/api/workspace')).body;assert.equal(s.rewards.members.find(x=>x.memberId===m.id).earnedCents,250);assert.equal(s.finance,undefined);assert.equal((await worker('/api/finance')).status,410);
 await f.app.store.transaction(d=>{d.treasury={batches:[],payments:[],privateWallet:'PRIVATE-HISTORICAL-WALLET',privateBalance:'99999999'};});
 for(const route of ['/api/data','/api/workspace','/api/rewards']){const response=await worker(route);assert.equal(response.status,200);assert(!JSON.stringify(response.body).includes('PRIVATE-HISTORICAL-WALLET'));assert(!JSON.stringify(response.body).includes('privateBalance'));}
 let d=(await f.owner('/api/data')).body;const pay={memberId:m.id,amount:'0.50',proof:'https://example.com/private-payment-evidence',note:'Private payment from project account',revision:d.revision};
 assert.equal((await worker('/api/rewards/payment',pay)).status,403);assert.equal((await f.owner('/api/rewards/payment',pay)).status,201);
 s=(await worker('/api/rewards')).body;assert.equal(s.members.find(x=>x.memberId===m.id).dueCents,200);assert.equal(s.payments[0].proof,undefined);assert.equal(s.payments[0].note,undefined);
 const own=(await f.owner('/api/rewards')).body;assert.equal(own.payments[0].proof,pay.proof);
 const backup=await f.owner('/api/backup',{password});assert.equal(backup.body.treasury.privateWallet,'PRIVATE-HISTORICAL-WALLET');assert.equal(backup.body.rewards.grants.length,1);validate(backup.body);
 assert.equal((await worker('/api/backup',{password:'creator-password-changed-993'})).status,403);
});

test('policy control is owner-only; budget failure rolls back work approval; quoted prices stay fixed',async t=>{
 const f=await fixture(t),worker=f.client();await f.owner('/api/members',{name:'Budget Creator',username:'budgetcreator',password});await worker('/api/login',{username:'budgetcreator',password});await worker('/api/password',{currentPassword:password,newPassword:'budgetcreator-changed-993'});
 const a=(await worker('/api/activities',{title:'First quoted post',category:'Marketing',platform:'Facebook',link:'https://example.com/first-post',rewardType:'social_post',requestKey:crypto.randomUUID()})).body.activity;
 const R=require('../lib/rewards'),policy=R.defaults();policy.types[0].effortMinutes=20;policy.memberWeeklyCents=250;let d=(await f.owner('/api/data')).body;
 assert.equal((await worker('/api/rewards/policy',{policy,revision:d.revision})).status,403);assert.equal((await f.owner('/api/rewards/policy',{policy,revision:d.revision})).status,201);
 const approval={status:'approved',version:1,rewardType:'social_post',originalConfirmed:true,evidenceVerified:true,qualityConfirmed:true};assert.equal((await f.owner(`/api/activities/${a.id}/review`,approval)).status,200);assert.equal(f.app.store.data.rewards.grants[0].amountCents,250);
 const b=(await worker('/api/activities',{title:'Second quoted post',category:'Marketing',platform:'Facebook',link:'https://example.com/second-post',rewardType:'social_post',requestKey:crypto.randomUUID()})).body.activity;assert.equal(b.rewardQuote.amountCents,500);
 assert.equal((await f.owner(`/api/activities/${b.id}/review`,approval)).status,409);assert.equal(f.app.store.data.activities.find(x=>x.id===b.id).status,'pending');assert.equal(f.app.store.data.rewards.grants.length,1);
});

test('referral purchase API grants exactly five percent, protects receipts and rejects self review',async t=>{
 const f=await fixture(t),worker=f.client(),other=f.client();const creator=(await f.owner('/api/members',{name:'Referral Creator',username:'refcreator',password})).body.member;await f.owner('/api/members',{name:'Unrelated Creator',username:'unrelated',password});
 for(const [client,username]of [[worker,'refcreator'],[other,'unrelated']]){await client('/api/login',{username,password});await client('/api/password',{currentPassword:password,newPassword:'changed-'+username+'-password-123'});}
 let d=(await worker('/api/data')).body;const submitted=await worker('/api/rewards/referral',{orderId:'seller:private-order-123',amount:'100',proof:'https://example.com/PRIVATE-PURCHASE-RECEIPT',revision:d.revision});assert.equal(submitted.status,201);
 let view=(await worker('/api/rewards')).body;assert.equal(view.referrals.length,1);assert.equal(view.referrals[0].proof,undefined);assert.equal(view.referrals[0].orderId,undefined);assert.equal((await other('/api/rewards')).body.referrals.length,0);
 const claim=f.app.store.data.rewards.referrals[0];d=(await f.owner('/api/data')).body;const body={id:claim.id,decision:'confirmed',amount:'100',buyerReference:'private-buyer-987',paymentVerified:true,attributionVerified:true,notSelfVerified:true,revision:d.revision};
 assert.equal((await worker('/api/rewards/referral-review',body)).status,403);assert.equal((await f.owner('/api/rewards/referral-review',body)).status,201);
 view=(await worker('/api/workspace')).body;assert.equal(view.rewards.members.find(m=>m.memberId===creator.id).referralEarnedCents,500);assert.equal(view.rewards.members.find(m=>m.memberId===creator.id).dueCents,500);assert(!JSON.stringify(view).includes('PRIVATE-PURCHASE-RECEIPT'));assert(!JSON.stringify(view).includes('private-buyer-987'));assert(!JSON.stringify(view).includes('seller:private-order-123'));
 assert.equal((await f.owner('/api/rewards')).body.referrals[0].buyerReference,'private-buyer-987');
 const disk=JSON.parse(await fs.readFile(path.join(f.dir,'team-data.json'),'utf8'));validate(disk);assert.equal(disk.rewards.referrals[0].commissionCents,500);
});

test('a Telegram submission cannot claim the X post price through the API',async t=>{const f=await fixture(t);const result=await f.owner('/api/activities',{title:'Short Telegram announcement',category:'Marketing',platform:'Telegram',rewardType:'social_post',link:'https://t.me/channel/price-test',requestKey:crypto.randomUUID()});assert.equal(result.status,201);assert.equal(result.body.activity.rewardType,'telegram_post');assert.equal(result.body.activity.rewardQuote.amountCents,50);const spoof=await f.owner('/api/activities',{title:'Mislabeled Telegram post',category:'Marketing',platform:'X (Twitter)',rewardType:'social_post',link:'https://t.me/channel/price-spoof',requestKey:crypto.randomUUID()});assert.equal(spoof.status,400);});

test('wallet ownership privacy, required profiles and owner-only SEVEN transfer preparation',async t=>{
  const f=await fixture(t),W=require('../lib/wallet'),recipient='mvines9iiHiQTysrwkJjGf2gb9Ex9jXJX8ns3qwf2kN';
  const created=await f.owner('/api/members',{name:'Wallet Member',username:'wallet_member',password});
  const id=created.body.member.id,member=f.client();
  await member('/api/login',{username:'wallet_member',password});
  await member('/api/password',{currentPassword:password,newPassword:'Wallet-member-new-123!'});
  let rows=(await member('/api/workspace')).body.members;
  assert.equal(rows.find(m=>m.role==='Owner').walletAddress,undefined);
  assert.equal(rows.find(m=>m.id===id).walletAddress,recipient);
  assert.equal((await f.owner('/api/workspace')).body.members.find(m=>m.id===id).walletAddress,recipient);
  assert.equal((await member('/api/profile',{name:'Wallet Member',photo:'',walletAddress:'not-a-wallet'})).status,400);
  assert.equal((await f.owner('/api/members',{name:'Missing Wallet',username:'missing_wallet',password,walletAddress:''})).status,400);
  const revision=f.app.store.data.revision;
  assert.equal((await member('/api/rewards/prepare-transfer',{memberId:id,revision,amount:'1'})).status,403);
  assert.equal((await f.owner('/api/rewards/prepare-transfer',{memberId:id,revision:revision-1,amount:'1'})).status,409);
  assert.equal((await f.owner('/api/rewards/prepare-transfer',{memberId:id,revision,amount:'1'})).status,400);
  assert.throws(()=>W.transfer(recipient,'1',{}),/configure/);
  const env={SEVEN_TOKEN_MINT:'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',SEVEN_TOKEN_DECIMALS:'6'};
  const transfer=W.transfer(recipient,'12.25',env),uri=new URL(transfer.uri);
  assert.equal(uri.searchParams.get('spl-token'),env.SEVEN_TOKEN_MINT);
  assert.equal(uri.searchParams.get('amount'),'12.25');
  for(const amount of ['0','-1','1e5','1.0000001','18446744073709551616'])assert.throws(()=>W.transfer(recipient,amount,env));
  assert.equal(W.validWallet('11111111111111111111111111111111'),false);
  // Legacy accounts may sign in and recover but must complete a wallet before submitting new work.
  await f.app.store.transaction(d=>{delete d.members.find(m=>m.id===id).walletAddress;});
  assert.equal((await member('/api/me')).status,200);
  assert.equal((await member('/api/activities',{title:'Missing wallet work',category:'Other',requestKey:crypto.randomUUID()})).status,400);
  assert.equal((await member('/api/profile',{name:'Wallet Member',photo:'',walletAddress:recipient})).status,200);
  assert.equal((await member('/api/me')).body.member.walletAddress,recipient);
});

test('configured SEVEN links use the saved wallet and never mutate the payment ledger',async t=>{
 const mint='EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'; // Test SPL mint only, not a claim about SEVEN identity.
 const f=await fixture(t,{SEVEN_TOKEN_MINT:mint,SEVEN_TOKEN_DECIMALS:'6'});
 const id=(await f.owner('/api/members',{name:'Paid Worker',username:'paidworker',password})).body.member.id;
 const worker=f.client();await worker('/api/login',{username:'paidworker',password});await worker('/api/password',{currentPassword:password,newPassword:'Paid-worker-changed-123!'});
 let revision=f.app.store.data.revision;
 const claim=await worker('/api/rewards/referral',{orderId:'testshop:wallet-link-001',amount:'100',proof:'https://example.com/wallet-link-order',revision});
 revision=f.app.store.data.revision;
 assert.equal((await f.owner('/api/rewards/referral-review',{id:claim.body.id,decision:'confirmed',amount:'100',buyerReference:'external-buyer-wallet-test',paymentVerified:true,attributionVerified:true,notSelfVerified:true,revision})).status,201);
 revision=f.app.store.data.revision;
 const before=JSON.stringify(f.app.store.data);
 const prepared=await f.owner('/api/rewards/prepare-transfer',{memberId:id,amount:'25',revision});
 assert.equal(prepared.status,200);assert.equal(prepared.body.recipient,f.app.store.data.members.find(m=>m.id===id).walletAddress);
 assert.equal(new URL(prepared.body.uri).searchParams.get('spl-token'),mint);
 assert.equal(JSON.stringify(f.app.store.data),before);
 assert.equal((await worker('/api/rewards/prepare-transfer',{memberId:id,amount:'25',revision})).status,403);
 await worker('/api/profile',{name:'Paid Worker',photo:''});
 assert.equal((await f.owner('/api/rewards/prepare-transfer',{memberId:id,amount:'25',revision})).status,409);
});
