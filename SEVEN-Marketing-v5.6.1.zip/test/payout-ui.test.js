'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const html=fs.readFileSync(require.resolve('../index.html'),'utf8');
function ui(status){
 const calls=[],selector={value:'phantom'},button={},error={};let rendered='';
 const ctx={payoutProviderName:'phantom',walletPicker:()=>'',tr:s=>s,esc:s=>String(s),usd:n=>String(n),walletText:s=>s,modal:(title,fields)=>{rendered=fields;},$:s=>s.includes('[name=signProvider]')?selector:s==='#signPayout'?button:s==='#formError'?error:null,SevenWallets:{provider:()=>({}),sign:async()=>{calls.push('sign');return {serialize:()=>new Uint8Array([1])};}},solanaWeb3:{Transaction:{from:()=>({})}},atob:()=>'',btoa:()=>'',api:async route=>{calls.push(route);return {job:{id:'job',status,transaction:'',source:'source',recipient:'recipient',amount:'5',usdCents:50}};},loadData:async()=>{},render:()=>{},location:{origin:'https://example.com'}};
 vm.runInNewContext(html.match(/function showPayoutJob\(job\)\{[^\n]+/)[0],ctx);
 return {ctx,calls,button,fields:()=>rendered};
}
test('expired payment is reconciled before opening wallet signing',async()=>{const u=ui('expired');u.ctx.showPayoutJob({id:'job',status:'prepared',transaction:'',amount:'5',source:'source',recipient:'recipient',usdCents:50});await u.button.onclick();assert.deepEqual(u.calls,['/api/payout/reconcile']);assert.match(u.fields(),/expired/);});
test('uncertain broadcast notice is visible and signing is preceded by reconciliation',async()=>{const u=ui('prepared');u.ctx.showPayoutJob({id:'job',status:'broadcast',notice:'Payment status is uncertain. Use Check payment status; do not start another transfer.'});assert.match(u.fields(),/Payment status is uncertain/);u.ctx.showPayoutJob({id:'job',status:'prepared',transaction:'',source:'source',recipient:'recipient',amount:'5',usdCents:50});await u.button.onclick();assert.deepEqual(u.calls,['/api/payout/reconcile','sign','/api/payout/submit']);});
