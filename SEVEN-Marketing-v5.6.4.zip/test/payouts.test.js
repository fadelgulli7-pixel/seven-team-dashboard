'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const crypto=require('node:crypto');const {Keypair,PublicKey,Transaction}=require('@solana/web3.js');const {TOKEN_PROGRAM_ID}=require('../lib/token');const bs58=require('bs58').default;const P=require('../lib/payouts');const R=require('../lib/rewards');const C=require('../lib/campaigns');
function fixture(provider='phantom'){const payer=Keypair.generate(),receiver=Keypair.generate();const owner={id:'owner',role:'Owner',name:'Owner'},member={id:'member',active:true,walletAddress:receiver.publicKey.toBase58()};const activity={id:'work',memberId:'member',status:'approved',rewardType:'social_post',link:'https://x.com/seven/status/1'};const d={revision:0,members:[owner,member],activities:[activity]};R.award(d,activity,{rewardType:'social_post',originalConfirmed:true,evidenceVerified:true,qualityConfirmed:true},owner);P.configure(d,{walletAddress:payer.publicKey.toBase58(),provider});const store={data:d,async transaction(fn){const next=structuredClone(this.data),r=await fn(next);next.revision++;P.validate(next);this.data=next;return r;}};
 let chainStatus=null,height=100,sends=0,throwSend=false;const rpc={async getAccountInfo(){const data=Buffer.alloc(82);data.writeBigUInt64LE(100000000000n,36);data[44]=9;data[45]=1;return {data,owner:TOKEN_PROGRAM_ID};},async getTokenAccountBalance(){return {value:{amount:'100000000000'}};},async getLatestBlockhash(){return {blockhash:Keypair.generate().publicKey.toBase58(),lastValidBlockHeight:150};},async getBlockHeight(){return height;},async getSignatureStatuses(){return {value:[chainStatus]};},async sendRawTransaction(raw){sends++;if(throwSend)throw Error('Timeout after possible broadcast');return bs58.encode(Transaction.from(raw).signature);}};
 const payout=P.create({},rpc);return {payer,owner,store,payout,settings:{status(v){chainStatus=v;},height(v){height=v;},throwSend(v){throwSend=v;},sends:()=>sends}};
}
test('signed Phantom payment is exact, reserved before broadcast, reconciled once and ledger-backed',async()=>{const f=fixture();const job=await f.payout.prepare(f.store,{memberId:'member',amount:'0.05',revision:0},f.owner);assert.equal(job.usdCents,250);P.validate(f.store.data);await assert.rejects(()=>f.payout.prepare(f.store,{memberId:'member',amount:'0.05',revision:1},f.owner),/already reserved/);const tx=Transaction.from(Buffer.from(job.transaction,'base64'));tx.sign(f.payer);const raw=tx.serialize().toString('base64');f.settings.throwSend(true);const unknown=await f.payout.submit(f.store,{jobId:job.id,signedTransaction:raw},f.owner);assert.equal(unknown.status,'broadcast');assert.ok(f.store.data.payoutJobs[0].signature);assert.equal(f.store.data.rewards.payments.length,0);assert.throws(()=>P.unreserved(f.store.data,'member'));
 f.settings.status({err:null,confirmationStatus:'finalized'});const paid=await f.payout.reconcile(f.store,job.id,f.owner);assert.equal(paid.status,'confirmed');assert.equal(f.store.data.rewards.payments.length,1);assert.equal(f.store.data.rewards.payments[0].amountCents,250);assert.equal(R.summary(f.store.data).dueCents,0);await f.payout.reconcile(f.store,job.id,f.owner);await f.payout.submit(f.store,{jobId:job.id,signedTransaction:raw},f.owner);assert.equal(f.settings.sends(),1);assert.equal(f.store.data.rewards.payments.length,1);P.validate(f.store.data);
});
test('tampered, wrong-signer and expired unsigned payments cannot create a payout',async()=>{const f=fixture();const job=await f.payout.prepare(f.store,{memberId:'member',amount:'0.05',revision:0},f.owner);const tx=Transaction.from(Buffer.from(job.transaction,'base64'));tx.instructions[1].data[1]^=1;tx.sign(f.payer);await assert.rejects(()=>f.payout.submit(f.store,{jobId:job.id,signedTransaction:tx.serialize().toString('base64')},f.owner),/does not match/);assert.equal(f.settings.sends(),0);f.settings.height(200);const expired=await f.payout.reconcile(f.store,job.id,f.owner);assert.equal(expired.status,'expired');assert.equal(f.store.data.rewards.payments.length,0);P.unreserved(f.store.data,'member');
});
test('chain failure never records payment; uncertain result never releases reservation',async()=>{const f=fixture();const j=await f.payout.prepare(f.store,{memberId:'member',amount:'0.05',revision:0},f.owner);const t=Transaction.from(Buffer.from(j.transaction,'base64'));t.sign(f.payer);await f.payout.submit(f.store,{jobId:j.id,signedTransaction:t.serialize().toString('base64')},f.owner);f.settings.height(500);assert.equal((await f.payout.reconcile(f.store,j.id,f.owner)).status,'broadcast');f.settings.status({err:{InstructionError:[1,'failed']},confirmationStatus:'finalized'});assert.equal((await f.payout.reconcile(f.store,j.id,f.owner)).status,'failed');assert.equal(f.store.data.rewards.payments.length,0);assert.equal(R.summary(f.store.data).dueCents,250);
});
test('campaign requires approved brief, per-member limits, spacing and independent quality scores',()=>{const owner={id:'owner',role:'Owner'},member={id:'member'};const d={activities:[],members:[owner,member]};const input={title:'SEVEN tutorial',objective:'Explain safe SEVEN mining',brief:'Use original footage and accurate steps, with no profit promises.',deadline:new Date(Date.now()+86400000).toISOString(),maxPerMember:2,gapHours:24};assert.throws(()=>C.create(d,input,member));const c=C.create(d,input,owner);C.validate(d);assert.equal(C.source(d,member,{campaignId:c.id,platform:'YouTube'}).id,c.id);d.activities.push({id:'a',memberId:'member',campaignId:c.id,platform:'YouTube',status:'pending',createdAt:new Date().toISOString()});assert.throws(()=>C.source(d,member,{campaignId:c.id,platform:'YouTube'}),/interval/);assert.equal(C.source(d,member,{campaignId:c.id,platform:'YouTube'},'a').id,c.id);assert.throws(()=>C.quality({score_accuracy:10,score_originality:20,score_usefulness:20,score_production:20,score_compliance:20}));const scores=C.quality({score_accuracy:15,score_originality:15,score_usefulness:15,score_production:15,score_compliance:15});assert.equal(Object.values(scores).reduce((a,b)=>a+b),75);c.active=false;assert.throws(()=>C.source(d,member,{campaignId:c.id,platform:'Discord'}));
});

test('Solflare-style provider signs real reserved transaction and server records only one confirmed payment',async()=>{const f=fixture('solflare'),W=require('../assets/wallets');const job=await f.payout.prepare(f.store,{memberId:'member',amount:'0.05',revision:0},f.owner);assert.equal(job.provider,'solflare');const scope={solflare:{isSolflare:true,publicKey:f.payer.publicKey,connect:async()=>true,signTransaction:async tx=>{tx.sign(f.payer);return tx;}}};const tx=Transaction.from(Buffer.from(job.transaction,'base64'));const signed=await W.sign('solflare',tx,job.source,scope);f.settings.status({err:null,confirmationStatus:'finalized'});const r=await f.payout.submit(f.store,{jobId:job.id,signedTransaction:signed.serialize().toString('base64')},f.owner);assert.equal(r.status,'confirmed');await f.payout.reconcile(f.store,job.id,f.owner);assert.equal(f.store.data.rewards.payments.length,1);assert.equal(f.settings.sends(),1);});

test('prepared fees prevent automatic wallet insertion; browser bundle preserves exact signed message',async()=>{
 const fs=require('node:fs'),vm=require('node:vm');const f=fixture(),job=await f.payout.prepare(f.store,{memberId:'member',amount:'5',revision:0},f.owner);
 const original=Transaction.from(Buffer.from(job.transaction,'base64'));
 const {ComputeBudgetProgram,ComputeBudgetInstruction}=require('@solana/web3.js');
 assert.equal(original.instructions.length,4);
 assert.ok(original.instructions[0].programId.equals(ComputeBudgetProgram.programId));
 assert.equal(ComputeBudgetInstruction.decodeSetComputeUnitLimit(original.instructions[0]).units,200000);
 assert.equal(ComputeBudgetInstruction.decodeSetComputeUnitPrice(original.instructions[1]).microLamports,10000n);
 const ctx=vm.createContext({console,TextEncoder,TextDecoder,URL,setTimeout,clearTimeout,crypto:crypto.webcrypto});
 vm.runInContext(fs.readFileSync(require.resolve('../assets/solana-web3.js'),'utf8'),ctx);
 ctx.raw=Array.from(Buffer.from(job.transaction,'base64'));ctx.secret=Array.from(f.payer.secretKey);
 vm.runInContext(`var tx=solanaWeb3.Transaction.from(Uint8Array.from(raw));
 // Model a wallet adding fees only when the application did not specify them.
 if(!tx.instructions.some(i=>i.programId.equals(solanaWeb3.ComputeBudgetProgram.programId)))tx.add(solanaWeb3.ComputeBudgetProgram.setComputeUnitPrice({microLamports:10000}));
 tx.sign(solanaWeb3.Keypair.fromSecretKey(Uint8Array.from(secret)));`,ctx);
 const encoded=Buffer.from(vm.runInContext('Array.from(tx.serialize())',ctx)).toString('base64');
 assert.equal(P.signedPayment(job,encoded).tx.serializeMessage().toString('base64'),job.message);
 f.settings.status({err:null,confirmationStatus:'confirmed'});
 assert.equal((await f.payout.submit(f.store,{jobId:job.id,signedTransaction:encoded},f.owner)).status,'confirmed');
 assert.equal(f.settings.sends(),1);
});

test('specific validation errors preserve reservations and never broadcast altered or unsigned bytes',async()=>{
 const f=fixture(),j=await f.payout.prepare(f.store,{memberId:'member',amount:'5',revision:0},f.owner),decode=()=>Transaction.from(Buffer.from(j.transaction,'base64'));
 const changed=decode();changed.instructions.at(-1).data[1]^=1;changed.sign(f.payer);
 await assert.rejects(()=>f.payout.submit(f.store,{jobId:j.id,signedTransaction:changed.serialize().toString('base64')},f.owner),e=>e.code==='PAYOUT_MESSAGE_CHANGED');
 const extra=decode();extra.add(require('@solana/web3.js').SystemProgram.transfer({fromPubkey:f.payer.publicKey,toPubkey:Keypair.generate().publicKey,lamports:1}));extra.sign(f.payer);
 assert.throws(()=>P.signedPayment(j,extra.serialize().toString('base64')),e=>e.code==='PAYOUT_MESSAGE_CHANGED');
 const fee=decode();fee.instructions[1]=require('@solana/web3.js').ComputeBudgetProgram.setComputeUnitPrice({microLamports:20000});fee.sign(f.payer);
 assert.throws(()=>P.signedPayment(j,fee.serialize().toString('base64')),e=>e.code==='PAYOUT_MESSAGE_CHANGED');
 const signer=Keypair.generate(),wrong=decode();wrong.feePayer=signer.publicKey;wrong.partialSign(signer,f.payer);
 assert.throws(()=>P.signedPayment(j,wrong.serialize().toString('base64')),e=>e.code==='PAYOUT_SIGNER');
 assert.throws(()=>P.signedPayment(j,j.transaction),e=>e.code==='PAYOUT_SIGNATURE');
 assert.throws(()=>P.signedPayment(j,'not base64!'),e=>e.code==='PAYOUT_ENCODING');
 const invalid=decode();invalid.sign(f.payer);invalid.signatures[0].signature[0]^=1;
 assert.throws(()=>P.signedPayment(j,invalid.serialize({verifySignatures:false}).toString('base64')),e=>e.code==='PAYOUT_SIGNATURE');
 assert.equal(f.settings.sends(),0);assert.equal(f.store.data.payoutJobs[0].status,'prepared');assert.equal(f.store.data.rewards.payments.length,0);assert.throws(()=>P.unreserved(f.store.data,'member'));
});

test('legacy prepared messages remain immutable and expire without modifying saved history',async()=>{
 const f=fixture(),j=await f.payout.prepare(f.store,{memberId:'member',amount:'1',revision:0},f.owner);
 const old=Transaction.from(Buffer.from(j.transaction,'base64'));old.instructions.splice(0,2);
 const legacy=f.store.data.payoutJobs[0];legacy.transaction=old.serialize({requireAllSignatures:false}).toString('base64');legacy.message=old.serializeMessage().toString('base64');
 const exact=Transaction.from(Buffer.from(legacy.transaction,'base64'));exact.sign(f.payer);
 assert.ok(P.signedPayment(legacy,exact.serialize().toString('base64')));
 const modified=Transaction.from(Buffer.from(legacy.transaction,'base64'));modified.add(require('@solana/web3.js').ComputeBudgetProgram.setComputeUnitPrice({microLamports:10000}));modified.sign(f.payer);
 assert.throws(()=>P.signedPayment(legacy,modified.serialize().toString('base64')),e=>e.code==='PAYOUT_MESSAGE_CHANGED');
 const message=legacy.message;f.settings.height(200);assert.equal((await f.payout.reconcile(f.store,j.id,f.owner)).status,'expired');assert.equal(f.store.data.payoutJobs[0].message,message);
 const next=await f.payout.prepare(f.store,{memberId:'member',amount:'1',revision:f.store.data.revision},f.owner);assert.notEqual(next.id,j.id);assert.equal(f.store.data.payoutJobs.length,2);
});

test('message diagnostics identify changed fees, blockhash and instructions without exporting signed transaction bytes',async()=>{
 const f=fixture(),j=await f.payout.prepare(f.store,{memberId:'member',amount:'6',revision:0},f.owner),decode=()=>Transaction.from(Buffer.from(j.transaction,'base64'));
 const fee=decode();fee.instructions[1]=require('@solana/web3.js').ComputeBudgetProgram.setComputeUnitPrice({microLamports:30000});fee.sign(f.payer);
 let report;try{P.signedPayment(j,fee.serialize().toString('base64'));}catch(e){assert.equal(e.code,'PAYOUT_MESSAGE_CHANGED');report=e.diagnostic;}
 assert.equal(report.blockhashChanged,false);assert.equal(report.feePayerChanged,false);assert.equal(report.expectedInstructionCount,4);assert.equal(report.returnedInstructionCount,4);assert.equal(report.changes.length,1);assert.equal(report.changes[0].index,1);assert.equal(report.changes[0].expected.microLamports,'10000');assert.equal(report.changes[0].returned.microLamports,'30000');assert.equal(report.changes[0].keysChanged,false);
 const block=decode();block.recentBlockhash=Keypair.generate().publicKey.toBase58();block.sign(f.payer);const b=P.messageDiagnostic(j,block);assert.equal(b.blockhashChanged,true);assert.deepEqual(b.changes,[]);
 const extra=decode();extra.add(require('@solana/web3.js').SystemProgram.transfer({fromPubkey:f.payer.publicKey,toPubkey:Keypair.generate().publicKey,lamports:1}));extra.sign(f.payer);const x=P.messageDiagnostic(j,extra);assert.equal(x.returnedInstructionCount,5);assert.equal(x.changes.at(-1).index,4);assert.equal(x.changes.at(-1).expected,null);
 const serial=JSON.stringify(report);assert.ok(!serial.includes(fee.serialize().toString('base64')));assert.ok(!serial.includes(fee.serializeMessage().toString('base64')));assert.ok(!serial.includes(bs58.encode(fee.signature)));assert.ok(!serial.includes('signedTransaction'));assert.equal(f.settings.sends(),0);
});

test('Phantom Lighthouse tail guards preserve the payment and remain in actual broadcast bytes',async()=>{
 const {LIGHTHOUSE}=require('../lib/payout-message'),{TransactionInstruction}=require('@solana/web3.js');const f=fixture(),j=await f.payout.prepare(f.store,{memberId:'member',amount:'5',revision:0},f.owner);
 const tx=Transaction.from(Buffer.from(j.transaction,'base64'));
 const source=tx.instructions.at(-1).keys[0].pubkey,recipient=tx.instructions.at(-1).keys[2].pubkey;
 // AssertAccountInfo::Lamports(0, >=), and AssertTokenAccount::Amount(0, >=).
 // Official instruction/enum fixtures are documented in test/fixtures/lighthouse-assertions.json.
 const fixtures=require('./fixtures/lighthouse-assertions.json');
 tx.add(new TransactionInstruction({programId:LIGHTHOUSE,keys:[{pubkey:source,isSigner:false,isWritable:false}],data:Buffer.from(fixtures.assertAccountInfoLamports,'hex')}),new TransactionInstruction({programId:LIGHTHOUSE,keys:[{pubkey:recipient,isSigner:false,isWritable:false}],data:Buffer.from(fixtures.assertTokenAccountAmount,'hex')}));
 tx.sign(f.payer);const raw=tx.serialize().toString('base64'),signed=P.signedPayment(j,raw);
 assert.equal(signed.tx.instructions.length,6);assert.notEqual(signed.tx.serializeMessage().toString('base64'),j.message);
 const result=await f.payout.submit(f.store,{jobId:j.id,signedTransaction:raw},f.owner);assert.equal(result.status,'broadcast');assert.equal(f.store.data.payoutJobs[0].signedTransaction,raw);assert.equal(Transaction.from(Buffer.from(f.store.data.payoutJobs[0].signedTransaction,'base64')).instructions.length,6);
 f.settings.status({err:null,confirmationStatus:'finalized'});assert.equal((await f.payout.reconcile(f.store,j.id,f.owner)).status,'confirmed');assert.equal(f.store.data.rewards.payments.length,1);await f.payout.reconcile(f.store,j.id,f.owner);assert.equal(f.store.data.rewards.payments.length,1);assert.equal(f.settings.sends(),1);
});

test('guard compatibility rejects payment edits, arbitrary programs, writes, new accounts, privilege changes and invalid signatures',async()=>{
 const {LIGHTHOUSE}=require('../lib/payout-message'),{TransactionInstruction,SystemProgram,ComputeBudgetProgram}=require('@solana/web3.js');const f=fixture(),j=await f.payout.prepare(f.store,{memberId:'member',amount:'5',revision:0},f.owner),decode=()=>Transaction.from(Buffer.from(j.transaction,'base64'));
 const target=decode().instructions.at(-1).keys[0].pubkey;
 const guard=(opcode=5,key=target)=>new TransactionInstruction({programId:LIGHTHOUSE,keys:[{pubkey:key,isSigner:false,isWritable:false}],data:Buffer.from([opcode,0,0,0,0])});
 const cases=[t=>{t.instructions.at(-1).data[1]^=1;t.add(guard());},t=>{t.recentBlockhash=Keypair.generate().publicKey.toBase58();t.add(guard());},t=>{t.instructions[1]=ComputeBudgetProgram.setComputeUnitPrice({microLamports:99999});t.add(guard());},t=>t.add(new TransactionInstruction({programId:Keypair.generate().publicKey,keys:[],data:Buffer.from([5,0,0])})),t=>t.add(guard(0)),t=>t.add(guard(1)),t=>t.add(guard(16)),t=>t.add(guard(255)),t=>t.add(guard(5,Keypair.generate().publicKey)),t=>{const g=guard();g.keys.push(g.keys[0]);t.add(g);},t=>{const g=guard();g.data=Buffer.alloc(513,5);t.add(g);},t=>{for(let i=0;i<4;i++)t.add(guard());},t=>{t.instructions.splice(0,0,guard());},t=>{t.instructions.pop();t.add(guard());},t=>{t.add(SystemProgram.transfer({fromPubkey:f.payer.publicKey,toPubkey:Keypair.generate().publicKey,lamports:1}),guard());},t=>{t.add(guard(5,t.instructions.at(-1).keys[1].pubkey));t.instructions.at(-1).keys[0].isWritable=true;}];
 for(const mutate of cases){const tx=decode();mutate(tx);tx.sign(f.payer);assert.throws(()=>P.signedPayment(j,tx.serialize().toString('base64')),e=>e.code==='PAYOUT_MESSAGE_CHANGED');}
 const bad=decode();bad.add(guard());bad.sign(f.payer);bad.signatures[0].signature[0]^=1;assert.throws(()=>P.signedPayment(j,bad.serialize({verifySignatures:false}).toString('base64')),e=>e.code==='PAYOUT_SIGNATURE');assert.equal(f.settings.sends(),0);assert.equal(f.store.data.payoutJobs[0].status,'prepared');
});

test('a reserved guarded signature cannot be replaced or paid twice, and guard chain failure never posts payment',async()=>{
 const {LIGHTHOUSE}=require('../lib/payout-message'),{TransactionInstruction}=require('@solana/web3.js'),f=fixture(),j=await f.payout.prepare(f.store,{memberId:'member',amount:'5',revision:0},f.owner);
 const sign=value=>{const t=Transaction.from(Buffer.from(j.transaction,'base64')),data=Buffer.from(require('./fixtures/lighthouse-assertions.json').assertAccountInfoLamports,'hex');data[3]=value;t.add(new TransactionInstruction({programId:LIGHTHOUSE,keys:[{pubkey:f.payer.publicKey,isSigner:false,isWritable:false}],data}));t.sign(f.payer);return t.serialize().toString('base64');};
 f.settings.throwSend(true);await f.payout.submit(f.store,{jobId:j.id,signedTransaction:sign(0)},f.owner);const signature=f.store.data.payoutJobs[0].signature;
 await assert.rejects(()=>f.payout.submit(f.store,{jobId:j.id,signedTransaction:sign(1)},f.owner),/different signed transaction/);assert.equal(f.store.data.payoutJobs[0].signature,signature);assert.equal(f.settings.sends(),1);assert.equal(f.store.data.rewards.payments.length,0);
 f.settings.status({err:{InstructionError:[4,{Custom:6000}]},confirmationStatus:'finalized'});assert.equal((await f.payout.reconcile(f.store,j.id,f.owner)).status,'failed');assert.equal(f.store.data.rewards.payments.length,0);assert.equal(R.summary(f.store.data).dueCents,250);
});
