'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const html=fs.readFileSync(require.resolve('../index.html'),'utf8');
function ui(status){
 const calls=[],selector={value:'phantom'},button={},error={};let rendered='';
 const ctx={translateLabel:s=>s,payoutProviderName:'phantom',walletPicker:()=>'',tr:s=>s,esc:s=>String(s),usd:n=>String(n),walletText:s=>s,modal:(title,fields)=>{rendered=fields;},$:s=>s.includes('[name=signProvider]')?selector:s==='#signPayout'?button:s==='#formError'?error:null,SevenWallets:{provider:()=>({}),sign:async()=>{calls.push('sign');return {serialize:()=>new Uint8Array([1])};}},solanaWeb3:{Transaction:{from:()=>({})}},atob:()=>'',btoa:()=>'',api:async route=>{calls.push(route);return {job:{id:'job',status,transaction:'',source:'source',recipient:'recipient',amount:'5',usdCents:50}};},loadData:async()=>{},render:()=>{},location:{origin:'https://example.com'}};
 vm.runInNewContext(html.match(/function showPaymentDiagnostic[\s\S]*?\n    }/)[0],ctx);
 vm.runInNewContext(html.match(/function showPayoutJob\(job\)\{[^\n]+/)[0],ctx);
 return {ctx,calls,button,fields:()=>rendered};
}
test('expired payment is reconciled before opening wallet signing',async()=>{const u=ui('expired');u.ctx.showPayoutJob({id:'job',status:'prepared',transaction:'',amount:'5',source:'source',recipient:'recipient',usdCents:50});await u.button.onclick();assert.deepEqual(u.calls,['/api/payout/reconcile']);assert.match(u.fields(),/expired/);});
test('uncertain broadcast notice is visible and signing is preceded by reconciliation',async()=>{const u=ui('prepared');u.ctx.showPayoutJob({id:'job',status:'broadcast',notice:'Payment status is uncertain. Use Check payment status; do not start another transfer.'});assert.match(u.fields(),/Payment status is uncertain/);u.ctx.showPayoutJob({id:'job',status:'prepared',transaction:'',source:'source',recipient:'recipient',amount:'5',usdCents:50});await u.button.onclick();assert.deepEqual(u.calls,['/api/payout/reconcile','sign','/api/payout/submit']);});
test('owner sees and copies diagnostic without download; blocked clipboard selects report text',async()=>{
 const u=ui('prepared'),nodes=[],copies=[];
 u.ctx.navigator={clipboard:{writeText:async text=>copies.push(text)}};
 u.ctx.document={createElement:tag=>({tagName:tag,style:{},setAttribute(){},focus(){this.focused=true;},select(){this.selected=true;}})};
 u.ctx.$=s=>s==='#formError'?{append:(...items)=>nodes.push(...items)}:s.includes('[name=signProvider]')?{value:'phantom'}:s==='#signPayout'?u.button:null;
 u.ctx.api=async route=>{if(route==='/api/payout/submit')throw Object.assign(Error('Changed message'),{code:'PAYOUT_MESSAGE_CHANGED',diagnostic:{format:'seven-payment-diagnostic-v1',expectedInstructionCount:4,returnedInstructionCount:4,blockhashChanged:true,changes:[{index:1,expected:{microLamports:'10000'},returned:{microLamports:'30000'}}]}});return {job:{id:'job',status:'prepared',transaction:'',source:'source',recipient:'recipient',amount:'5',usdCents:50}};};
 u.ctx.showPayoutJob({id:'job',status:'prepared',transaction:'',source:'source',recipient:'recipient',amount:'5',usdCents:50});await u.button.onclick();
 assert.equal(nodes.length,4);assert.match(nodes[1].textContent,/blockhash changed: true/);assert.match(nodes[1].textContent,/price: 10000 -> 30000/);assert.equal(nodes[2].readOnly,true);assert.equal(nodes[3].type,'button');await nodes[3].onclick();
 const d=JSON.parse(copies[0]);assert.equal(d.changes[0].returned.microLamports,'30000');assert.equal(d.provider,'phantom');assert.ok(!('signedTransaction'in d));
 u.ctx.navigator.clipboard.writeText=async()=>{throw Error('Clipboard blocked');};await nodes[3].onclick();assert.equal(nodes[2].focused,true);assert.equal(nodes[2].selected,true);
 delete u.ctx.navigator;await nodes[3].onclick();assert.equal(nodes[2].selected,true);
});
